package com.greatlearningServiceImplements;

import com.greatlearningService.Examtip;

public class RevisonTip implements Examtip {

	@Override
	public String getExamTip() {
		// TODO Auto-generated method stub
		return "do revison";
	}

}
