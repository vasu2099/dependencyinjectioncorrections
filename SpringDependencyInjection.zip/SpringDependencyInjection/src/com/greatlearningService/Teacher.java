package com.greatlearningService;

public interface Teacher extends Examtip {
	public String getHomework();
	 public String getExamTip();
}
