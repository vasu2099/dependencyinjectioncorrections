package com.greatlearningService;

public interface Examtip {
 public String getExamTip();
}
